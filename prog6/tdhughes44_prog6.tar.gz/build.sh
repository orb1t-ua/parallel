nvcc p6.cu -o p6.out -std=c++11 -O3
