building:
	./run.sh
running:
	./p6.out <N>