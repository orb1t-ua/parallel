#!/bin/bash

clear

#to build you will need openGL 3.3, glew, and glfw3

g++ main.cpp lifematrix.cpp lifematrix.h -o visualizer -std=c++11 -Wall -I/usr/include -L/usr/lib -lglfw -lGLEW -lGL -fopenmp -DOMP_PARALLEL -O3

