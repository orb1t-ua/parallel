#!/bin/bash

clear

g++ -o pi1.out -Wfatal-errors -std=c++11 -lpthread pi1.cpp

g++ -o pi2.out -Wfatal-errors -std=c++11 -lpthread pi2.cpp

g++ -o pi3.out -Wfatal-errors -std=c++11 -lpthread pi3.cpp

g++ -o pi4.out -Wfatal-errors -std=c++11 -lpthread pi4.cpp

g++ -o pi5.out -Wfatal-errors -std=c++11 -lpthread pi5.cpp

